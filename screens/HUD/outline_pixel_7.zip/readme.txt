
True Type Font: Outline Pixel-7 version 1.0


EULA
-==-
The fonts Outline Pixel-7 is freeware for home using.


DESCRIPTION
-=========-

Original outline pixel font. Native size is 15 points. Solid font is included also.
Latin and Cyrillic code pages are supported.

Files in pixel_font-7.zip:
       	readme.txt     				this file.
        outline_pixel-7.ttf    			Outline Pixel-7 regular font
        outline_pixel-7_solid.ttf    		Outline Pixel-7 solid font
	outline_pixel-7_windows_1251.fon   	Outline Pixel-7 regular font in Windows OS "FON" format Cyrillic codepage
	outline_pixel-7_windows_1252.fon   	Outline Pixel-7 regular font in Windows OS "FON" format Latin codepage
	outline_pixel-7_solid_windows_1251.fon  Outline Pixel-7 solid font in Windows OS "FON" format Cyrillic codepage
	outline_pixel-7_solid_windows_1252.fon  Outline Pixel-7 solid font in Windows OS "FON" format Latin codepage
	outline_pixel-7_screen.png		preview image

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-

Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-

Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-

Sizenko Alexander
Style-7
http://www.styleseven.com
Created: November 21 2012